const express = require('express');
const pacienteModel = require('../model/pacienteModel');
const upload = require('../helpers/upload/upload');

/* GERENCIADOR DE ROTAS*/
const router = express.Router();

/* ROTA DE INSERÇÃO DE AUTOR(POST)*/
router.post('/paciente/inserir', upload.array('imagens', 2), (req,res)=>{
    
    let { nome, telefone, celular_paciente, email_paciente, foto_paciente} = req.body;


    let foto_paciente = req.files[1].path;

    pacienteModel.create(
        {
            paciente,
            telefone,
            celular_paciente,
            email_paciente,
            detalhes,
            foto_paciente
        }
    ).then(
        ()=>{
            return res.status(201).json({
                errorStatus:false,
                mensageStatus: 'paciente CADASTRADO COM SUCESSO!'
            });
        }
    )
    .catch(
        (error)=>{
            return res.status(500).json({
                errorStatus:true,
                mensageStatus: error
            });
        }
    );

});

/* ROTA DE SELEÇÃO DE AUTOR(GET)*/
router.get('/paciente/selecionar', (req,res)=>{
    pacienteModel.findAll()
        .then(
            (pacientes)=>{
                res.json(pacientes);
            }
        )
        .catch(
            (error)=>{
                return res.status(500).json({
                    errorStatus:true,
                    mensageStatus: error
                });
            }
        );
});

router.get('/paciente/selecionar/:id', (req,res)=>{
    let {id} = req.params;
    pacienteModel.findByPk(id)
        .then(
            (paciente)=>{
                res.json(paciente);
            }
        )
        .catch(
            (error)=>{
                return res.status(500).json({
                    errorStatus:true,
                    mensageStatus: error
                });
            }
        );
});

router.get('/paciente/selecionar/:paciente', (req,res)=>{
    let {paciente} = req.params;
    pacienteModel.findOne({where:{paciente:paciente}})
        .then(
            (paciente)=>{
                res.json(paciente);
            }
        )
        .catch(
            (error)=>{
                return res.status(500).json({
                    errorStatus:true,
                    mensageStatus: error
                });
            }
        );
});


/* ROTA DE ALTERAÇÃO DE AUTOR(PUT)*/
router.put('/paciente/alterar', (req,res)=>{

    let {paciente, telefone, celular_paciente, email_paciente, detalhes, foto_paciente, id} = req.body;

    pacienteModel.update(
        {
            paciente,
            telefone,
            celular_paciente,
            email_paciente,
            detalhes,
            foto_paciente
        },
        {
            where:{id}
        }
    ).then(
        ()=>{
            return res.status(201).json({
                errorStatus:false,
                mensageStatus: 'paciente ALTERADO COM SUCESSO!'
            });
        }
    )
    .catch(
        (error)=>{
            return res.status(500).json({
                errorStatus:true,
                mensageStatus: error
            });
        }
    );

})

/* ROTA DE EXCLUSÃO DE AUTOR(DELETE)*/
router.delete('/paciente/excluir/:id', (req,res)=>{
    
    let {id} = req.params;

    pacienteModel.destroy(
        {where:{id}}
    ).then(
        ()=>{
            return res.status(200).json({
                errorStatus:false,
                mensageStatus:'PACIENTE EXCLUIDO COM SUCESSO'
            });
        }
    ).catch(
        (error)=>{
            return res.status(500).json({
                errorStatus:true,
                mensageStatus: error
            });
        }
    );

})

module.exports = router;