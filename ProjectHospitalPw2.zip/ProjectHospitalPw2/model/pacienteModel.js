/* IMPORTAÇÃO DO SEQUELIZE */
const sequelize  = require('sequelize');

/* IMPORTAÇÃO DA CONEXÃO COM O BANCO DE DADOS */
const connection = require('../database/database');

const paciente = connection.define(
    'tbl_paciente',
    {
        nome:{
            type: sequelize.STRING(500),
            allowNull:false
        },
        telefone:{
            type: sequelize.STRING(500),
            allowNull:false
        },
        celular_paciente:{
            type: sequelize.STRING(500),
            allowNull:false
        },
        email_paciente:{
            type: sequelize.STRING(500),
            allowNull:false
        },
        foto_paciente:{
            type: sequelize.TEXT,
            allowNull:false
        },
    }

);

/*
A CHAVE PRIMÁRIA (1) DE CATEGORIA VIRA UMA CHAVE ESTRAGEIRA (N) EM LIVRO
*/
/*categoria.hasMany(livro);

/*
A CHAVE ESTRANGEIRA DE LIVRO (N) É ACHAVE PRIMARIA DE CATEGORIA (1)
*/
/*livro.belongsTo(categoria);

//livro.sync({force:false});

module.exports = livro; */